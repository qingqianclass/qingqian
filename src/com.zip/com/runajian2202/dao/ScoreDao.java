package com.runajian2202.dao;

import com.runajian2202.Model.Score;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * @author qingqian
 * 成绩sql方法包
 */
public class ScoreDao {
    public static ResultSet list(Connection conn ,Score s) throws SQLException {
        StringBuilder sbb = new StringBuilder("select * from score");
        if (s.getSid()!=0){
            sbb.append(" where sid="+s.getSid());
        }
        PreparedStatement ps=conn.prepareStatement(sbb.toString());
        return ps.executeQuery();
    }
    public static int add(Connection conn, Score s) throws SQLException {
        String sql="insert into score(sid,sname,chinese,math,english,sum) value(?,?,?,?,?,?)";
        PreparedStatement ps=conn.prepareStatement(sql);
        ps.setInt(1,s.getSid());
        ps.setString(2,s.getSname());
        ps.setDouble(3, s.getChinese());
        ps.setDouble(4, s.getMath());
        ps.setDouble(5,s.getEnglish());
        ps.setDouble(6,s.getSum());
        return ps.executeUpdate();
    }
    public static int delete(Connection conn,Score s) throws SQLException {
        String sql="DELETE FROM score WHERE sid="+s.getSid();
        PreparedStatement ps=conn.prepareStatement(sql);
        return ps.executeUpdate();
    }
    public static int Update(Connection conn, Score s) throws SQLException {
        String sql="UPDATE score set chinese="+s.getChinese()+",math="+s.getMath()+",english="+s.getEnglish()+",sum="+s.getSum()+" where "+"sid="+s.getSid();
        PreparedStatement ps = conn.prepareStatement(sql);
        return ps.executeUpdate();
    }
    public static ResultSet sum(Connection conn) throws SQLException {
        String sql="SELECT COALESCE(SUM(chinese),0)AS score,COALESCE(sum(math),0)AS score,COALESCE(SUM(english),0)AS score  FROM score";
        PreparedStatement ps=conn.prepareStatement(sql);
        return ps.executeQuery();
    }
    public static ResultSet average(Connection conn) throws SQLException {
        String sql="SELECT ROUND(AVG(chinese),2)AS score,ROUND(AVG(math),2) AS score,ROUND(AVG(english),2)AS score FROM score";
        PreparedStatement ps=conn.prepareStatement(sql);
        return ps.executeQuery();
    }
    public static ResultSet maximum(Connection conn) throws SQLException {
        String sql="SELECT MAX(chinese)AS score,MAX(math)AS score,MAX(english)AS score FROM score";
        PreparedStatement ps=conn.prepareStatement(sql);
        return ps.executeQuery();
    }
    public static ResultSet minimum(Connection conn) throws SQLException {
        String sql="SELECT min(chinese)AS score,min(math)AS score,min(english)AS score FROM score";
        PreparedStatement ps=conn.prepareStatement(sql);
        return ps.executeQuery();
    }
    public static ResultSet sort(Connection conn) throws SQLException {
        String sql="SELECT * FROM score ORDER BY sum DESC";
        PreparedStatement ps = conn.prepareStatement(sql);
        return ps.executeQuery();
    }

}
